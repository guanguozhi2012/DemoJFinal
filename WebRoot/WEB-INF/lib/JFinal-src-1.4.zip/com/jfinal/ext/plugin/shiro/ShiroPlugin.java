package com.jfinal.ext.plugin.shiro;

import com.jfinal.plugin.IPlugin;

public class ShiroPlugin implements IPlugin {
	
	public boolean start() {
		throw new RuntimeException("Not finish!!!");
	}
	
	public boolean stop() {
		throw new RuntimeException("Not finish!!!");
	}
}
