package com.jfinal.ext.plugin.redis;

public class RedisKit {
	
}
