package com.jfinal.ext.render;

import com.jfinal.render.Render;

/**
 * 生成静态 html
 */
public class StaticHtmlRender extends Render {
	
	private static final long serialVersionUID = 1438855188898365097L;
	
	public void render() {
		throw new RuntimeException("Not finish!!!");
	}
}
